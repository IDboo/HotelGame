﻿using HotelGame.Core.Entities;
using System.Collections.Generic;

namespace HotelGame.Entities.Concrete
{
    public class RoomMaterial : BaseEntity<int>
    {
        public string Name { get; set; }

    }

}
