﻿using Microsoft.AspNetCore.Identity;

namespace HotelGame.Entities.Concrete
{
    public class UserToken : IdentityUserToken<int>
    {

    }
}