﻿using Microsoft.AspNetCore.Identity;

namespace HotelGame.Entities.Concrete
{
    public class UserLogin : IdentityUserLogin<int>
    {
    }
}