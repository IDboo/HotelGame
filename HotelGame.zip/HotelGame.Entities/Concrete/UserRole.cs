﻿using Microsoft.AspNetCore.Identity;

namespace HotelGame.Entities.Concrete
{
    public class UserRole : IdentityUserRole<int>
    {
    }
}