﻿namespace HotelGame.Entities.DTOs.RoomMaterials
{
    public class RoomMaterialAddDto
    {
        public string Name { get; set; }
    }
}
