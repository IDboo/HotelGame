﻿namespace HotelGame.Entities.DTOs.RoomMaterials
{

    public class RoomMaterialUpdateDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
