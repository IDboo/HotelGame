﻿namespace HotelGame.Entities.DTOs.Customers
{
    public class CustomerUpdateDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public int PeopleCount { get; set; }
    }
}
