﻿namespace HotelGame.Entities.DTOs.Customers
{
    public class CustomerAddDto
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public int PeopleCount { get; set; }

    }
}
