﻿using HotelGame.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelGame.Entities.DTOs.PlayerRoomMaterials
{
    public class DefaultLevelMaterialDto
    {

        public List<RMTelevision> RMTelevisions { get; set; }
    }
}
