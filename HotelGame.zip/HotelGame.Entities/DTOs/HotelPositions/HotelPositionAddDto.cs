﻿namespace HotelGame.Entities.DTOs.HotelPositions
{
    public class HotelPositionAddDto
    {
        public string Name { get; set; }
        // Diğer gerekli özellikler eklenebilir
    }
}
