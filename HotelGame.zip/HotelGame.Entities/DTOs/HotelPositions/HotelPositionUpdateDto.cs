﻿namespace HotelGame.Entities.DTOs.HotelPositions
{

    public class HotelPositionUpdateDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        // Diğer gerekli özellikler eklenebilir
    }
}
