﻿namespace HotelGame.Entities.DTOs.PlayerHotelPositions
{
    public class PlayerHotelPositionAddDto
    {
        public int PlayerHotelId { get; set; }
        public int HotelPositionId { get; set; }
        public int StaffCount { get; set; }
    }
}
