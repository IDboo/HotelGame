﻿namespace HotelGame.Entities.DTOs.PlayerHotelStaffs
{
    public class PlayerHotelStaffAddDto
    {
        public int PlayerHotelPositionId { get; set; }
        public int StaffId { get; set; }
    }
}
