﻿namespace HotelGame.Entities.DTOs.PlayerHotelStaffs
{
    public class PlayerHotelStaffUpdateDto
    {
        public int Id { get; set; }
        public int PlayerHotelPositionId { get; set; }
        public int StaffId { get; set; }
    }
}
