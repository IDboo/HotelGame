﻿using HotelGame.Entities.Concrete;

namespace HotelGame.WebMVC.Helper.Abstract
{

    public interface IUserAccessor
    {

        User GetUser();
    }

}
