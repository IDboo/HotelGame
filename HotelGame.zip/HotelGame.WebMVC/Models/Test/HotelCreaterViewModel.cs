﻿namespace HotelGame.WebMVC.Models.Test
{
    public class HotelCreaterViewModel
    {
        public string HotelName { get; set; }
    }
}
