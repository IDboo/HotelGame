﻿using HotelGame.Entities.Concrete;
using System.Collections.Generic;

namespace HotelGame.WebMVC.Models.Test
{
    public class RoomMaterialViewTest
    {
        public List<RoomMaterial> RoomMaterials { get; set; }
    }
}
