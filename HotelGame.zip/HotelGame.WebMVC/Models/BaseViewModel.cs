﻿namespace HotelGame.WebMVC.Models
{
    public class BaseViewModel
    {
        public string Message { get; set; }
    }
}
