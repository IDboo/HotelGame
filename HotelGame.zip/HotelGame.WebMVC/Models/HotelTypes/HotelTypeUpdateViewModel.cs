﻿namespace HotelGame.WebMVC.Models.HotelTypes
{
    public class HotelTypeUpdateViewModel : BaseViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
