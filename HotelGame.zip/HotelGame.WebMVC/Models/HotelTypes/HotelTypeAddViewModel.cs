﻿namespace HotelGame.WebMVC.Models.HotelTypes
{
    public class HotelTypeAddViewModel : BaseViewModel
    {
        public string Name { get; set; }

    }
}
