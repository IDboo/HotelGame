﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace HotelGame.DataAccess.Migrations
{
    public partial class mig_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    County = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DateofBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ImagePath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PeopleCount = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HotelPositions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HotelPositions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HotelTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HotelTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Multipliers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Coefficient = table.Column<int>(type: "int", maxLength: 5, nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Multipliers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMAirConditions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMAirConditions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMBathRooms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMBathRooms", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMBeds",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMBeds", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMCarpets",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMCarpets", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMTelevisions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMTelevisions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RMToilets",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Level = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    QualityPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RMToilets", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RoomMaterial",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoomMaterial", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RoomTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PeopleCount = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RoomTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Staff",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Wage = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Staff", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PlayerHotels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HotelTypeId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    HotelName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    HotelQuality = table.Column<int>(type: "int", nullable: false),
                    HotelLevel = table.Column<int>(type: "int", nullable: false),
                    HotelMoney = table.Column<int>(type: "int", nullable: false),
                    CustomerCommentPointAvarage = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayerHotels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayerHotels_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerHotels_HotelTypes_HotelTypeId",
                        column: x => x.HotelTypeId,
                        principalTable: "HotelTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PlayerHotelPositions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerHotelId = table.Column<int>(type: "int", nullable: false),
                    HotelPositionId = table.Column<int>(type: "int", nullable: false),
                    StaffCount = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayerHotelPositions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayerHotelPositions_HotelPositions_HotelPositionId",
                        column: x => x.HotelPositionId,
                        principalTable: "HotelPositions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerHotelPositions_PlayerHotels_PlayerHotelId",
                        column: x => x.PlayerHotelId,
                        principalTable: "PlayerHotels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PlayerRooms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerHotelId = table.Column<int>(type: "int", nullable: false),
                    RoomTypeId = table.Column<int>(type: "int", nullable: false),
                    RoomDailyPrice = table.Column<int>(type: "int", nullable: false),
                    Availability = table.Column<bool>(type: "bit", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayerRooms", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayerRooms_PlayerHotels_PlayerHotelId",
                        column: x => x.PlayerHotelId,
                        principalTable: "PlayerHotels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRooms_RoomTypes_RoomTypeId",
                        column: x => x.RoomTypeId,
                        principalTable: "RoomTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PlayerHotelStaff",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerHotelPositionId = table.Column<int>(type: "int", nullable: false),
                    StaffId = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayerHotelStaff", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayerHotelStaff_PlayerHotelPositions_PlayerHotelPositionId",
                        column: x => x.PlayerHotelPositionId,
                        principalTable: "PlayerHotelPositions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerHotelStaff_Staff_StaffId",
                        column: x => x.StaffId,
                        principalTable: "Staff",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerRoomId = table.Column<int>(type: "int", nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    CustomerComment = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    CustomerCommentPoint = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bookings_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Bookings_PlayerRooms_PlayerRoomId",
                        column: x => x.PlayerRoomId,
                        principalTable: "PlayerRooms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PlayerRoomMaterials",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerRoomId = table.Column<int>(type: "int", nullable: false),
                    RMTelevisionId = table.Column<int>(type: "int", nullable: false),
                    RMToiletId = table.Column<int>(type: "int", nullable: false),
                    RMAirConditionId = table.Column<int>(type: "int", nullable: false),
                    RMBathRoomId = table.Column<int>(type: "int", nullable: false),
                    RMBedId = table.Column<int>(type: "int", nullable: false),
                    RMCarpetId = table.Column<int>(type: "int", nullable: false),
                    CreatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlayerRoomMaterials", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_PlayerRooms_PlayerRoomId",
                        column: x => x.PlayerRoomId,
                        principalTable: "PlayerRooms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMAirConditions_RMAirConditionId",
                        column: x => x.RMAirConditionId,
                        principalTable: "RMAirConditions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMBathRooms_RMBathRoomId",
                        column: x => x.RMBathRoomId,
                        principalTable: "RMBathRooms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMBeds_RMBedId",
                        column: x => x.RMBedId,
                        principalTable: "RMBeds",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMCarpets_RMCarpetId",
                        column: x => x.RMCarpetId,
                        principalTable: "RMCarpets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMTelevisions_RMTelevisionId",
                        column: x => x.RMTelevisionId,
                        principalTable: "RMTelevisions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PlayerRoomMaterials_RMToilets_RMToiletId",
                        column: x => x.RMToiletId,
                        principalTable: "RMToilets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Description", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { 2, "9b3ebb5a-8f73-4829-b83e-b1c887576ec4", "User Account", "User", "USER" },
                    { 3, "625f3132-37fe-42d4-a87a-590e8fd93ae1", "ProjectAdmin Account", "ProjectAdmin", "PROJECTADMİN" },
                    { 1, "663aee4b-0be6-4ea6-9483-f20bc67b9722", "Admin Account", "Admin", "ADMIN" }
                });

            migrationBuilder.InsertData(
                table: "HotelTypes",
                columns: new[] { "Id", "CreatedTime", "IsActive", "Name", "UpdatedTime" },
                values: new object[] { 1, new DateTime(2024, 4, 16, 20, 3, 14, 696, DateTimeKind.Utc).AddTicks(4613), true, "Butik Otel", new DateTime(2024, 4, 16, 20, 3, 14, 696, DateTimeKind.Utc).AddTicks(4903) });

            migrationBuilder.InsertData(
                table: "RMAirConditions",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(7827), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(9586), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(9592), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(9593), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(9594), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 703, DateTimeKind.Local).AddTicks(9596), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RMBathRooms",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(3925), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(3924), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(3921), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(3915), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(2899), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 708, DateTimeKind.Local).AddTicks(3923), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RMBeds",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(4111), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(5329), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(5337), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(5338), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(5340), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 709, DateTimeKind.Local).AddTicks(5341), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RMCarpets",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(6824), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(6822), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(6813), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(5596), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(6820), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 710, DateTimeKind.Local).AddTicks(6823), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RMTelevisions",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 705, DateTimeKind.Local).AddTicks(9613), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 706, DateTimeKind.Local).AddTicks(800), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 706, DateTimeKind.Local).AddTicks(806), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 706, DateTimeKind.Local).AddTicks(807), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 706, DateTimeKind.Local).AddTicks(809), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 706, DateTimeKind.Local).AddTicks(810), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RMToilets",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Level", "Name", "Price", "QualityPoint", "UpdatedTime" },
                values: new object[,]
                {
                    { 4, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(2672), null, true, 4, "4 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 6, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(2675), null, true, 6, "6 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(2664), null, true, 2, "2 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(2671), null, true, 3, "3 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 1, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(1532), null, true, 1, "1 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, new DateTime(2024, 4, 16, 23, 3, 14, 707, DateTimeKind.Local).AddTicks(2673), null, true, 5, "5 Seviye", 20, 20, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "RoomTypes",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Name", "PeopleCount", "UpdatedTime" },
                values: new object[,]
                {
                    { 3, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1627), null, true, "Superiour Double Oda", 2, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1628) },
                    { 4, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1630), null, true, "Aile Odası", 4, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1631) }
                });

            migrationBuilder.InsertData(
                table: "RoomTypes",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Name", "PeopleCount", "UpdatedTime" },
                values: new object[] { 1, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1615), null, true, "Standart Double Oda", 2, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1617) });

            migrationBuilder.InsertData(
                table: "RoomTypes",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Name", "PeopleCount", "UpdatedTime" },
                values: new object[] { 2, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1624), null, true, "Standart Twin Oda", 2, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1625) });

            migrationBuilder.InsertData(
                table: "RoomTypes",
                columns: new[] { "Id", "CreatedTime", "ImageUrl", "IsActive", "Name", "PeopleCount", "UpdatedTime" },
                values: new object[] { 5, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1632), null, true, "King Size Oda", 2, new DateTime(2024, 4, 16, 20, 3, 14, 701, DateTimeKind.Utc).AddTicks(1633) });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_CustomerId",
                table: "Bookings",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_PlayerRoomId",
                table: "Bookings",
                column: "PlayerRoomId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotelPositions_HotelPositionId",
                table: "PlayerHotelPositions",
                column: "HotelPositionId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotelPositions_PlayerHotelId",
                table: "PlayerHotelPositions",
                column: "PlayerHotelId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotels_HotelTypeId",
                table: "PlayerHotels",
                column: "HotelTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotels_UserId",
                table: "PlayerHotels",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotelStaff_PlayerHotelPositionId",
                table: "PlayerHotelStaff",
                column: "PlayerHotelPositionId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerHotelStaff_StaffId",
                table: "PlayerHotelStaff",
                column: "StaffId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_PlayerRoomId",
                table: "PlayerRoomMaterials",
                column: "PlayerRoomId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMAirConditionId",
                table: "PlayerRoomMaterials",
                column: "RMAirConditionId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMBathRoomId",
                table: "PlayerRoomMaterials",
                column: "RMBathRoomId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMBedId",
                table: "PlayerRoomMaterials",
                column: "RMBedId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMCarpetId",
                table: "PlayerRoomMaterials",
                column: "RMCarpetId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMTelevisionId",
                table: "PlayerRoomMaterials",
                column: "RMTelevisionId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRoomMaterials_RMToiletId",
                table: "PlayerRoomMaterials",
                column: "RMToiletId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRooms_PlayerHotelId",
                table: "PlayerRooms",
                column: "PlayerHotelId");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerRooms_RoomTypeId",
                table: "PlayerRooms",
                column: "RoomTypeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "Bookings");

            migrationBuilder.DropTable(
                name: "Multipliers");

            migrationBuilder.DropTable(
                name: "PlayerHotelStaff");

            migrationBuilder.DropTable(
                name: "PlayerRoomMaterials");

            migrationBuilder.DropTable(
                name: "RoomMaterial");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "PlayerHotelPositions");

            migrationBuilder.DropTable(
                name: "Staff");

            migrationBuilder.DropTable(
                name: "PlayerRooms");

            migrationBuilder.DropTable(
                name: "RMAirConditions");

            migrationBuilder.DropTable(
                name: "RMBathRooms");

            migrationBuilder.DropTable(
                name: "RMBeds");

            migrationBuilder.DropTable(
                name: "RMCarpets");

            migrationBuilder.DropTable(
                name: "RMTelevisions");

            migrationBuilder.DropTable(
                name: "RMToilets");

            migrationBuilder.DropTable(
                name: "HotelPositions");

            migrationBuilder.DropTable(
                name: "PlayerHotels");

            migrationBuilder.DropTable(
                name: "RoomTypes");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "HotelTypes");
        }
    }
}
