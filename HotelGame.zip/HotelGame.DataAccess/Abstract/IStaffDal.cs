﻿using HotelGame.Core.DataAccess.Abstract;
using HotelGame.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelGame.DataAccess.Abstract
{
    public interface IStaffDal : IEntityRepository<Staff>
    {


    }
}
