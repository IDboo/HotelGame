﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelGame.Core.Entities.Abstract
{
    public interface IEntity
    {

    }
}
